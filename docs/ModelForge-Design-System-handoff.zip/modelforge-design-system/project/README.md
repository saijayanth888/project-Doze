# ModelForge Design System

## Overview

**ModelForge** is a self-evolving LLM platform that autonomously spawns, trains, evaluates, and promotes AI models through a continuous evolutionary loop. The product is both a **production operations dashboard** (mission control for model evolution) and a **public-facing landing page** to attract open-source contributors, enterprise customers, and investors.

### Products / Surfaces
| Surface | Route | Description |
|---------|-------|-------------|
| Landing Page | `/` | Public-facing hero + architecture showcase |
| Evolution Dashboard | `/dashboard` | Real-time ops: status, scores, GPU, activity |
| Model Lineage Tree | `/lineage` | Interactive family tree of all model generations |
| Benchmarks | `/benchmarks` | Score tables, heatmaps, trend charts |
| Inference Playground | `/playground` | Side-by-side prompt comparison across generations |
| Settings | `/settings` | Evolution config, API keys, system info |

### Sources
- **Codebase**: `model-forge/` (mounted via File System Access API — paths start with `model-forge/`)
  - `src/agents/evolution_agent.py` — LangGraph state machine (the core loop)
  - `src/api/main.py` — FastAPI REST + WebSocket backend
  - `src/services/lineage_db.py` — PostgreSQL + pgvector lineage & vector store
  - `src/services/evaluator.py` — lm-eval benchmark harness (MMLU, ARC, HellaSwag, GSM8K, HumanEval)
  - `src/services/trainer.py` — LoRA fine-tuning via TRL + PEFT + DeepSpeed
  - `src/services/data_curator.py` — Weakness-targeted dataset curation + synthetic generation
  - `src/services/model_registry.py` — Champion tracking
  - `scripts/init_db.sql` — Full PostgreSQL schema with pgvector indexes
  - `docker-compose.yml` — Full stack: API, React frontend, Ollama, vLLM, n8n, PostgreSQL, Redis
- **No Figma link provided.** Design system created from codebase, prompt spec, and product context.

### Tech Stack (for UI reference)
- **Agent Logic**: LangGraph (state machine)
- **Workflows**: n8n (scheduling, notifications)
- **API**: FastAPI (REST + WebSocket)
- **Frontend**: React + Tailwind CSS
- **Dev Inference**: Ollama (:11434)
- **Eval Inference**: vLLM (:8001)
- **Training**: TRL + PEFT + DeepSpeed (LoRA adapters)
- **Tracking**: W&B + PostgreSQL/pgvector
- **Infra**: Docker Compose on NVIDIA DGX Spark

---

## CONTENT FUNDAMENTALS

### Voice & Tone
- **Authoritative, technical, direct.** This is mission-critical software for AI researchers and ML engineers. No marketing fluff.
- **Terse.** Labels are short. Actions are imperative verbs. Descriptions are factual.
- **No hedging.** "Champion: Gen 23" not "Estimated best model: Generation 23 (approximate)."
- **First person avoided in UI.** Never "Your models" or "My dashboard" — just "Models" / "Dashboard."
- **Numbers are the voice.** Data speaks louder than description. Let metrics lead.

### Casing
- **Title Case** for nav items, section headers, page titles: "Model Lineage", "Evolution Dashboard"
- **Sentence case** for descriptions, status messages, tooltips
- **ALL CAPS** for status badges/chips: `RUNNING`, `PROMOTED`, `DISCARDED`, `IDLE`
- **lowercase** for technical identifiers: `llama-3.1-8b`, `gen-23`, `arc_challenge`, `humaneval`
- **Monospace** for paths, IDs, model names: `~/training/gen23-a3b1-final`

### Copy Examples
- "Spawn. Train. Evaluate. Promote. Repeat." ← tagline (imperative, rhythmic)
- "Gen 23 promoted over parent by +0.034 avg score" ← event feed (precise delta)
- "Weakness detected: reasoning, code generation" ← weakness report (factual)
- "Child discarded: regression on MMLU (−4.2%)" ← decision reason (specific)
- "Champion Score: 0.847 · Generation 47 · Last Evolution: 2h ago" ← ticker (dot-separated)
- "5,000 samples curated from Open-Orca, synthetic GSM8K" ← data log (source-cited)

### Emoji & Unicode
- **No emoji.** This is mission control, not a consumer app.
- **Unicode bullets/arrows used sparingly**: `→`, `↑`, `↓`, `·`, `▶`, `■`
- **Status symbols via CSS classes**, not emoji: pulsing green dot, colored badge

### Terminology Glossary
| Term | Definition |
|------|------------|
| Champion | The current best-performing model (winner of the last promotion) |
| Generation | One iteration of the evolution loop (parent → child → decision) |
| Child | A LoRA-finetuned candidate model, challenger to the current champion |
| Adapter | A LoRA adapter file (small delta weights on top of base model) |
| Promoted | Child won, becomes the new champion |
| Discarded | Child lost, adapter archived |
| Weak category | A benchmark where the champion scores below average |
| Evolution run | A full autonomous session (may span many generations) |

---

## VISUAL FOUNDATIONS

### Color System
See `colors_and_type.css` for all CSS variables.

**Backgrounds** (near-black, blue-undertone layering):
- `--bg-primary: #06080d` — page background
- `--bg-secondary: #0c1018` — sidebar, panels
- `--bg-card: #111827` — card surfaces
- `--bg-elevated: #1a2235` — dropdowns, modals, tooltips

**Accents**:
- `--accent-primary: #76b900` — NVIDIA green; used for live/running/promoted states, CTAs, glow effects
- `--accent-secondary: #818cf8` — indigo; used for intelligence/AI motifs, secondary actions
- `--accent-evolution: linear-gradient(135deg, #818cf8, #c084fc, #f472b6)` — the evolution gradient; used on the lineage tree champion path and evolution section borders

**Text**:
- `--text-primary: #f1f5f9` — headings, primary labels
- `--text-secondary: #94a3b8` — body, descriptions
- `--text-muted: #475569` — placeholders, disabled, timestamps

**Semantic**:
- `--success: #22c55e` — promoted, healthy
- `--warning: #f59e0b` — caution, stalled
- `--danger: #ef4444` — discarded, error, regression

**Border**: `--border: #1e293b` — single-pixel borders on all cards/panels

### Typography
See `colors_and_type.css` for full declarations.

| Role | Font | Weight | Usage |
|------|------|--------|-------|
| Display / Hero | Instrument Serif | 400 | Hero headlines, section titles on landing page |
| UI Sans | Geist Sans (fallback: Satoshi, DM Sans) | 400–600 | Nav, labels, buttons, body |
| Mono / Data | Geist Mono (fallback: IBM Plex Mono) | 400–500 | Scores, metrics, paths, code, IDs |

**Type Scale**:
- Hero: 4–5rem Instrument Serif
- Section title: 2rem Geist Sans 600
- Card title: 1rem Geist Sans 600
- Body: 0.875rem Geist Sans 400
- Data/metric: 2–3rem Geist Mono 500 (large numbers)
- Label/caption: 0.75rem Geist Sans 400 uppercase letter-spacing

### Backgrounds & Texture
- **Dot-grid pattern**: radial-gradient dots at `--text-muted` opacity ~0.15, 20px grid spacing. Applied to dashboard main area for mission-control feel.
- **No photography or illustration**. The UI IS the content.
- **Gradient meshes** on landing page hero only (subtle, dark, moving).
- **Full-bleed section blocks** for landing page sections (alternating bg-primary / bg-secondary).

### Animation
- **Spring/bounce easing**: `cubic-bezier(0.34, 1.56, 0.64, 1)` for births, promotions, counter flips
- **Smooth easing**: `cubic-bezier(0.16, 1, 0.3, 1)` for slides, fades, entrances
- **Loop easing**: `ease-in-out` for ambient/infinite animations
- **All animations respect**: `@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }`

### Full Animation System (15 animations)

**Brand animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| DNA Helix Loader | `dna-rotate` / `helix-spin` | 2s linear ∞ | `DNAHelix` component — all loading states |
| Evolution gradient shimmer | `shimmer-gradient` | 3s linear ∞ | EvolutionStatus border when running |

**Data animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| Flip counter (odometer) | `digit-roll-up` / `digit-roll-out` | 600ms, stagger 80ms/digit | Generation counter in EvolutionStatus |
| Count-up entrance | `count-up-anim` | 600ms ease-out | All KPI metric values on mount |
| Score sparklines | `sparkline-draw` / `sparkline-in` | 800ms | Inline sparklines in ChampionCard, ScoreBar |
| Chart line draw | D3 stroke-dashoffset | 1500ms ease-out | ScoreTrendsChart |

**Tree animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| Node birth spring | `node-birth` | 500ms cubic-bezier(0.34,1.56,0.64,1) | All lineage tree nodes on mount |
| Node discard shake | `node-discard` | 600ms ease-in-out | Discarded nodes in lineage tree |
| Particle burst | `particle-burst` | 400ms ease-out | Promoted nodes in lineage tree |
| Champion crown float | `crown-float` | 3s ease-in-out ∞ | Crown icon on champion card + lineage node |

**Layout animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| Card entrance stagger | `slide-up-fade` | 400ms, delay=`i*80ms` | Every card/panel on page load |
| Sidebar indicator slide | CSS `transition: top 300ms ease-out` | 300ms | Sidebar active nav bar |
| Page transitions | `fade-up` | 200ms | Page content swap |

**Interactive animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| Magnetic hover + ripple | `ripple-out` + JS transform | 600ms | Primary action buttons |
| Radar ping | `radar-ping` | 2s ease-out ∞ | Live status indicator when running |
| Benchmark crosshair | JS hover + CSS transition | 100ms | Benchmark heatmap cells |
| Typing headline reveal | JS interval + `cursor-blink` | 60ms/char | Landing page hero headline |

**Ambient animations**
| Name | Keyframe | Duration | Component |
|------|----------|----------|-----------|
| Training wave | `wave-shift` / `wave-flow` | 2s ease-in-out ∞ | EvolutionStatus bottom when training |
| Ticker scroll | `ticker-scroll` | 30s linear ∞ | Landing page live stats ticker |
| Gradient mesh drift | `mesh-drift-1..4` | 40–55s ease-in-out ∞ | Landing hero background |

### Hover & Press States
- **Cards**: `background` lightens by one step (`--bg-card` → `--bg-elevated`), 1px border becomes `--accent-primary` at 30% opacity
- **Buttons (primary)**: brightness 1.1, box-shadow adds green glow `0 0 16px rgba(118,185,0,0.4)`
- **Buttons (ghost)**: background fades to `--bg-elevated`, border color to `--accent-secondary`
- **Nav items**: text goes from `--text-muted` to `--text-primary`, left border 2px `--accent-primary`
- **Tree nodes**: scale 1.05, glow ring with node color
- **Press states**: scale(0.97), brightness 0.95 on active, 80ms

### Cards
- Background: `--bg-card` (`#111827`)
- Border: `1px solid var(--border)` (`#1e293b`)
- Border-radius: `8px` (moderate, not aggressively rounded)
- Inner glow on hover: `inset 0 0 0 1px rgba(118,185,0,0.15)`
- No drop shadows (they fight the dark bg). Elevation via border + bg lightness.
- Padding: `1.5rem` standard, `1rem` for compact metric cards

### Borders & Radius
- Standard radius: `8px` for cards/modals
- Small radius: `4px` for badges/chips/inputs
- Pill radius: `9999px` for status dots, tags
- 1px borders only — no thick borders
- Animated gradient border (evolution engine): `border-image` or pseudo-element rotate trick

### Shadows & Elevation
| Level | Value |
|-------|-------|
| None (flat) | cards on dark bg |
| Glow (active) | `0 0 24px rgba(118,185,0,0.25)` |
| Glow (evolution) | `0 0 32px rgba(129,140,248,0.3)` |
| Tooltip | `0 8px 32px rgba(0,0,0,0.5)` |

### Layout Rules
- **Fixed left sidebar**: 240px wide, collapsible to 64px icon-only mode
- **Fixed top bar**: 56px, `--bg-secondary`, `z-index: 50`
- **Main content**: padded 1.5rem, CSS grid for dashboard panels
- **No max-width containers on dashboard** — fills available space
- **Landing page**: max-width 1280px centered, generous section padding
- **Grid breakpoints**: mobile (1 col), tablet (2 col), desktop (3+ col)

### Iconography (preview)
- **Icon library**: Lucide React (CDN) — stroke-weight 1.5, clean and modern
- **Size**: 16px for inline/nav, 20px for card headers, 24px for hero/section
- **Color**: `--text-muted` default, `--accent-primary` for active/live states
- See full ICONOGRAPHY section below

---

## ICONOGRAPHY

### Icon System
**Lucide React** (https://unpkg.com/lucide-react) via CDN. Stroke weight 1.5px. Used throughout the UI.

No custom icon font. No embedded SVGs in code (except the logo mark). No emoji as icons.

### Key Icon Mappings
| Concept | Lucide Icon |
|---------|------------|
| Dashboard | `LayoutDashboard` |
| Models | `Brain` |
| Lineage Tree | `GitBranch` |
| Benchmarks | `BarChart2` |
| Playground | `MessageSquare` |
| Settings | `Settings2` |
| Evolution Run | `Dna` |
| Start/Play | `Play` |
| Stop | `Square` |
| Promoted | `TrendingUp` |
| Discarded | `TrendingDown` |
| GPU | `Cpu` |
| Champion | `Trophy` |
| Warning | `AlertTriangle` |
| Info | `Info` |
| Link / External | `ExternalLink` |
| GitHub | `Github` |
| Training | `Zap` |
| Evaluate | `FlaskConical` |
| Curate Data | `Database` |
| Compare | `ArrowLeftRight` |
| Timer | `Clock` |
| Generation | `RefreshCw` |

### Logo
- **Wordmark**: "ModelForge" — "Model" in Geist Sans 600 (text-primary), "Forge" in accent-primary (#76b900)
- **Mark**: A stylized chain/helix glyph (DNA + forge anvil concept) — rendered as SVG in `assets/logo.svg`
- **Badge variant**: compact mark only, used in favicon and collapsed sidebar
- See `assets/` for SVG files

---

## FILES INDEX

```
/
├── README.md                          ← This file
├── SKILL.md                           ← Claude Code skill descriptor
├── colors_and_type.css                ← CSS variables: colors, typography, tokens
├── assets/
│   ├── logo.svg                       ← ModelForge wordmark SVG
│   ├── logo-mark.svg                  ← Mark-only variant
│   └── dot-grid.svg                   ← Background texture pattern
├── preview/
│   ├── colors-base.html               ← Base color palette swatches
│   ├── colors-semantic.html           ← Semantic / status colors
│   ├── type-display.html              ← Display type (Instrument Serif)
│   ├── type-ui.html                   ← UI sans (Geist Sans)
│   ├── type-mono.html                 ← Mono / data type (Geist Mono)
│   ├── type-scale.html                ← Full type scale
│   ├── spacing-tokens.html            ← Spacing, radius, border tokens
│   ├── shadows-elevation.html         ← Shadow / elevation system
│   ├── components-buttons.html        ← Button variants
│   ├── components-badges.html         ← Status badges & chips
│   ├── components-cards.html          ← Card patterns
│   ├── components-inputs.html         ← Form inputs
│   ├── components-nav.html            ← Sidebar nav items
│   └── components-metrics.html        ← Metric/KPI display components
└── ui_kits/
    ├── dashboard/
    │   ├── README.md
    │   ├── index.html                 ← Full dashboard prototype
    │   ├── Sidebar.jsx
    │   ├── TopBar.jsx
    │   ├── EvolutionStatus.jsx
    │   ├── ScoreTrendsChart.jsx
    │   ├── ChampionCard.jsx
    │   ├── LineageTree.jsx
    │   └── ActivityFeed.jsx
    └── landing/
        ├── README.md
        ├── index.html                 ← Full landing page prototype
        ├── Hero.jsx
        ├── HowItWorks.jsx
        └── Footer.jsx
```
