// ModelForge Shared Components
// Load with: <script type="text/babel" src="Shared.jsx"></script>

// ─── Fonts & Base ────────────────────────────────────────
const MF_FONTS = `@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700;900&display=swap');`;

// ─── Logo ────────────────────────────────────────────────
function MFLogo({ size = 'md', collapsed = false }) {
  const sizes = { sm: 20, md: 28, lg: 36 };
  const h = sizes[size] || 28;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <svg width={h * 0.8} height={h} viewBox="0 0 36 40" fill="none">
        <path d="M8 2 C8 10, 20 10, 20 20 C20 30, 8 30, 8 38" stroke="#76b900" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        <path d="M28 2 C28 10, 16 10, 16 20 C16 30, 28 30, 28 38" stroke="#818cf8" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
        <line x1="10" y1="10" x2="26" y2="10" stroke="#76b900" strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
        <line x1="10" y1="20" x2="26" y2="20" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
        <line x1="10" y1="30" x2="26" y2="30" stroke="#76b900" strokeWidth="1.5" strokeLinecap="round" opacity="0.7"/>
        <circle cx="8" cy="2" r="2.5" fill="#76b900"/>
        <circle cx="28" cy="2" r="2.5" fill="#818cf8"/>
        <circle cx="8" cy="38" r="2.5" fill="#76b900"/>
        <circle cx="28" cy="38" r="2.5" fill="#818cf8"/>
      </svg>
      {!collapsed && (
        <span style={{ fontFamily: "'Outfit', sans-serif", fontSize: h * 0.64, fontWeight: 600, letterSpacing: '-0.02em', lineHeight: 1 }}>
          <span style={{ color: '#f1f5f9' }}>Model</span>
          <span style={{ color: '#76b900' }}>Forge</span>
        </span>
      )}
    </div>
  );
}

// ─── Live Dot ────────────────────────────────────────────
function LiveDot({ color = '#76b900', idle = false }) {
  return (
    <span style={{
      display: 'inline-block', width: 7, height: 7,
      borderRadius: '50%', background: idle ? '#475569' : color,
      boxShadow: idle ? 'none' : `0 0 6px ${color}88`,
      animation: idle ? 'none' : 'mf-pulse 1.5s ease-in-out infinite',
      flexShrink: 0,
    }} />
  );
}

// ─── Badge ───────────────────────────────────────────────
function Badge({ type = 'idle', children }) {
  const styles = {
    running:   { bg: 'rgba(34,197,94,0.12)',  color: '#22c55e', border: 'rgba(34,197,94,0.3)' },
    promoted:  { bg: 'rgba(118,185,0,0.12)',  color: '#76b900', border: 'rgba(118,185,0,0.3)' },
    discarded: { bg: 'rgba(239,68,68,0.12)',  color: '#ef4444', border: 'rgba(239,68,68,0.3)' },
    idle:      { bg: '#1a2235',               color: '#475569', border: '#1e293b' },
    warning:   { bg: 'rgba(245,158,11,0.12)', color: '#f59e0b', border: 'rgba(245,158,11,0.3)' },
    training:  { bg: 'rgba(129,140,248,0.12)',color: '#818cf8', border: 'rgba(129,140,248,0.3)' },
  };
  const s = styles[type] || styles.idle;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 8px', borderRadius: 4,
      background: s.bg, color: s.color,
      border: `1px solid ${s.border}`,
      fontFamily: "'Outfit', sans-serif", fontSize: 10,
      fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase',
    }}>
      {type === 'running' && <LiveDot color="#22c55e" />}
      {children}
    </span>
  );
}

// ─── KPI Card ────────────────────────────────────────────
function KPICard({ label, value, sub, valueColor = '#f1f5f9', bar = null, live = false }) {
  return (
    <div style={{
      background: '#111827', border: '1px solid #1e293b', borderRadius: 8,
      padding: '14px 16px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 6 }}>
        {live && <LiveDot />}
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569' }}>{label}</span>
      </div>
      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '1.75rem', fontWeight: 500, lineHeight: 1, color: valueColor }}>{value}</div>
      {sub && <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#475569', marginTop: 4 }}>{sub}</div>}
      {bar !== null && (
        <div style={{ marginTop: 8, height: 3, background: '#1a2235', borderRadius: 2, overflow: 'hidden' }}>
          <div style={{ width: `${bar.pct}%`, height: '100%', background: bar.color || '#76b900', borderRadius: 2 }} />
        </div>
      )}
    </div>
  );
}

// ─── Section Header ──────────────────────────────────────
function SectionHeader({ title, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>{title}</span>
      {action}
    </div>
  );
}

// ─── Button ──────────────────────────────────────────────
function MFButton({ variant = 'primary', size = 'md', children, onClick, disabled = false }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    gap: 6, cursor: disabled ? 'not-allowed' : 'pointer',
    fontFamily: "'Outfit',sans-serif", fontWeight: 500,
    border: '1px solid transparent', borderRadius: 4,
    transition: 'all 150ms ease-in-out', outline: 'none',
    opacity: disabled ? 0.5 : 1,
  };
  const sizes = {
    sm: { padding: '4px 10px', fontSize: 12 },
    md: { padding: '6px 14px', fontSize: 13 },
    lg: { padding: '10px 20px', fontSize: 14 },
  };
  const variants = {
    primary: { background: '#76b900', color: '#000', borderColor: '#76b900' },
    secondary: { background: 'transparent', color: '#76b900', borderColor: 'rgba(118,185,0,0.4)' },
    ghost: { background: 'transparent', color: '#94a3b8', borderColor: '#1e293b' },
    danger: { background: 'rgba(239,68,68,0.12)', color: '#ef4444', borderColor: 'rgba(239,68,68,0.3)' },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{ ...base, ...sizes[size], ...variants[variant] }}>
      {children}
    </button>
  );
}

// ─── Progress Step ───────────────────────────────────────
function EvolutionStep({ label, active, done }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: done ? 'rgba(118,185,0,0.15)' : active ? 'rgba(118,185,0,0.2)' : '#1a2235',
        border: `2px solid ${done ? '#76b900' : active ? '#76b900' : '#1e293b'}`,
        flexShrink: 0,
      }}>
        {done
          ? <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#76b900" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20,6 9,17 4,12"/></svg>
          : active
            ? <LiveDot color="#76b900" />
            : <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#1e293b' }} />
        }
      </div>
      <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 12, fontWeight: active ? 600 : 400, color: active ? '#f1f5f9' : done ? '#76b900' : '#475569' }}>{label}</span>
    </div>
  );
}

// Export everything to window
Object.assign(window, { MFLogo, LiveDot, Badge, KPICard, SectionHeader, MFButton, EvolutionStep, MF_FONTS });
