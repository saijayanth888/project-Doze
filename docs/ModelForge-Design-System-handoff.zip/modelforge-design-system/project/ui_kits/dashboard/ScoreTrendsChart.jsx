// ModelForge — Score Trends Chart
// Uses Recharts (loaded in index.html)
// Depends on: Shared.jsx

function ScoreTrendsChart({ data }) {
  if (!window.Recharts) {
    return (
      <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, padding: '16px', height: 270, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: '#475569' }}>Score Trends — chart library loading…</span>
      </div>
    );
  }
  const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } = window.Recharts;

  const BENCH_COLORS = {
    mmlu:        '#76b900',
    arc_challenge: '#818cf8',
    hellaswag:   '#38bdf8',
    gsm8k:       '#f59e0b',
    humaneval:   '#f472b6',
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: '#1a2235', border: '1px solid #273347', borderRadius: 6, padding: '10px 14px', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}>
        <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#475569', marginBottom: 6 }}>Gen {label}</div>
        {payload.map(p => (
          <div key={p.dataKey} style={{ display: 'flex', justifyContent: 'space-between', gap: 16, marginBottom: 2 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: p.color }}>{p.dataKey}</span>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#f1f5f9', fontWeight: 600 }}>{p.value?.toFixed(3)}</span>
          </div>
        ))}
      </div>
    );
  };

  // Find promoted gens
  const promotedGens = data.filter(d => d.promoted).map(d => d.generation);

  return (
    <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, padding: '16px 16px 8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Score Trends</span>
        <div style={{ display: 'flex', gap: 10 }}>
          {Object.entries(BENCH_COLORS).map(([b, c]) => (
            <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 16, height: 2, background: c, borderRadius: 1 }} />
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#475569' }}>{b}</span>
            </div>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
          <XAxis
            dataKey="generation"
            tick={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, fill: '#475569' }}
            axisLine={{ stroke: '#1e293b' }}
            tickLine={false}
            label={{ value: 'Generation', position: 'insideBottomRight', offset: -4, fontFamily: "'JetBrains Mono',monospace", fontSize: 10, fill: '#475569' }}
          />
          <YAxis
            domain={[0.3, 0.85]}
            tick={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, fill: '#475569' }}
            axisLine={false}
            tickLine={false}
            tickFormatter={v => v.toFixed(2)}
          />
          <Tooltip content={<CustomTooltip />} />
          {promotedGens.map(gen => (
            <ReferenceLine key={gen} x={gen} stroke="rgba(118,185,0,0.2)" strokeDasharray="3 3" />
          ))}
          {Object.entries(BENCH_COLORS).map(([bench, color]) => (
            <Line
              key={bench}
              type="monotone"
              dataKey={bench}
              stroke={color}
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 4, fill: color, strokeWidth: 0 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

Object.assign(window, { ScoreTrendsChart });
