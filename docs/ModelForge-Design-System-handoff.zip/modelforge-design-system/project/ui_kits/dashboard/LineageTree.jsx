// ModelForge — Lineage Tree (D3-based)
// Depends on: Shared.jsx, D3 loaded in index.html

function LineageTree({ nodes, edges, onNodeClick, selectedNode }) {
  const svgRef = React.useRef(null);
  const [dimensions, setDimensions] = React.useState({ width: 800, height: 500 });

  React.useEffect(() => {
    if (!svgRef.current || !nodes.length) return;
    const d3 = window.d3;
    const { width, height } = dimensions;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    // Build hierarchy
    const nodeMap = {};
    nodes.forEach(n => { nodeMap[n.id] = { ...n, children: [] }; });
    edges.forEach(e => {
      if (nodeMap[e.source] && nodeMap[e.target]) {
        nodeMap[e.source].children.push(nodeMap[e.target]);
      }
    });
    const root = nodeMap['base'] || Object.values(nodeMap)[0];
    if (!root) return;

    const hierarchy = d3.hierarchy(root, d => d.children);
    const treeLayout = d3.tree().size([width - 80, height - 80]);
    treeLayout(hierarchy);

    const g = svg.append('g').attr('transform', 'translate(40,40)');

    // Zoom
    svg.call(d3.zoom().scaleExtent([0.3, 3]).on('zoom', (event) => {
      g.attr('transform', event.transform);
    }));

    // Draw edges
    g.selectAll('.edge')
      .data(hierarchy.links())
      .join('path')
      .attr('class', 'edge')
      .attr('d', d3.linkVertical().x(d => d.x).y(d => d.y))
      .attr('fill', 'none')
      .attr('stroke', d => d.target.data.promoted ? 'rgba(118,185,0,0.4)' : 'rgba(239,68,68,0.25)')
      .attr('stroke-width', d => d.target.data.promoted ? 1.5 : 1);

    // Draw nodes
    const nodeG = g.selectAll('.node')
      .data(hierarchy.descendants())
      .join('g')
      .attr('class', 'node')
      .attr('transform', d => `translate(${d.x},${d.y})`)
      .style('cursor', 'pointer')
      .on('click', (event, d) => onNodeClick && onNodeClick(d.data));

    // Score → radius (14–26px)
    const scoreVals = nodes.map(n => {
      const vals = Object.values(n.scores || {});
      return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0.5;
    });
    const minS = Math.min(...scoreVals) || 0.4;
    const maxS = Math.max(...scoreVals) || 0.9;
    const getR = (scores) => {
      const vals = Object.values(scores || {});
      const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0.5;
      return 12 + ((avg - minS) / (maxS - minS + 0.001)) * 12;
    };

    nodeG.append('circle')
      .attr('r', d => getR(d.data.scores))
      .attr('fill', d => {
        if (d.data.generation === 0) return 'rgba(129,140,248,0.2)';
        return d.data.promoted ? 'rgba(118,185,0,0.15)' : 'rgba(239,68,68,0.12)';
      })
      .attr('stroke', d => {
        if (d.data.id === selectedNode?.id) return '#f1f5f9';
        if (d.data.generation === 0) return '#818cf8';
        return d.data.promoted ? '#76b900' : '#ef4444';
      })
      .attr('stroke-width', d => d.data.id === selectedNode?.id ? 2.5 : 1.5)
      .attr('filter', d => d.data.promoted ? 'url(#glow-green)' : 'none');

    // Labels
    nodeG.append('text')
      .attr('y', d => getR(d.data.scores) + 12)
      .attr('text-anchor', 'middle')
      .attr('fill', d => d.data.promoted ? '#76b900' : '#475569')
      .attr('font-family', "'JetBrains Mono', monospace")
      .attr('font-size', 9)
      .text(d => d.data.generation === 0 ? 'base' : `g${d.data.generation}`);

    // Glow filter
    const defs = svg.append('defs');
    const filter = defs.append('filter').attr('id', 'glow-green');
    filter.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const merge = filter.append('feMerge');
    merge.append('feMergeNode').attr('in', 'coloredBlur');
    merge.append('feMergeNode').attr('in', 'SourceGraphic');

  }, [nodes, edges, selectedNode, dimensions]);

  return (
    <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, overflow: 'hidden', position: 'relative' }}>
      <div style={{ padding: '14px 16px 10px', borderBottom: '1px solid #1e293b', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Model Lineage</span>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'rgba(118,185,0,0.3)', border: '1.5px solid #76b900' }} />
            <span style={{ fontSize: 10, fontFamily: "'Outfit',sans-serif", color: '#475569' }}>Promoted</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'rgba(239,68,68,0.15)', border: '1.5px solid #ef4444' }} />
            <span style={{ fontSize: 10, fontFamily: "'Outfit',sans-serif", color: '#475569' }}>Discarded</span>
          </div>
          <span style={{ fontSize: 10, fontFamily: "'Outfit',sans-serif", color: '#475569' }}>Scroll to zoom · Drag to pan</span>
        </div>
      </div>
      <svg ref={svgRef} width="100%" height={500} style={{ display: 'block', background: '#0c1018' }} />
    </div>
  );
}

Object.assign(window, { LineageTree });
