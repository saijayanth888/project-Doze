// ModelForge — Champion Card + Latest Generation Card
// Depends on: Shared.jsx

function ScoreBar({ label, value, max = 1, color = '#76b900' }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#475569' }}>{label}</span>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#f1f5f9', fontWeight: 500 }}>{value.toFixed(3)}</span>
      </div>
      <div style={{ height: 4, background: '#1a2235', borderRadius: 2, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 2, transition: 'width 0.6s ease-out' }} />
      </div>
    </div>
  );
}

function ChampionCard({ champion }) {
  const benchColors = { mmlu: '#76b900', arc_challenge: '#818cf8', hellaswag: '#38bdf8', gsm8k: '#f59e0b', humaneval: '#f472b6' };
  const avgScore = Object.values(champion.scores).reduce((a, b) => a + b, 0) / Object.values(champion.scores).length;

  return (
    <div style={{ background: '#111827', border: '1px solid rgba(118,185,0,0.25)', borderRadius: 8, padding: 18, height: '100%', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Champion</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#76b900" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/>
            <path d="M4 22h16"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>
          </svg>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#76b900', fontWeight: 600 }}>Gen {champion.generation}</span>
        </div>
      </div>

      {/* Name + avg */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 14, color: '#76b900', fontWeight: 600 }}>{champion.name}</div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 4 }}>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '2rem', fontWeight: 500, color: '#f1f5f9', lineHeight: 1 }}>{avgScore.toFixed(3)}</span>
          <span style={{ fontSize: 11, color: '#475569' }}>avg score</span>
        </div>
        <div style={{ fontSize: 11, color: '#475569', marginTop: 2, fontFamily: "'JetBrains Mono',monospace" }}>
          {champion.adapterPath}
        </div>
      </div>

      {/* Score bars */}
      <div>
        {Object.entries(champion.scores).map(([bench, score]) => (
          <ScoreBar key={bench} label={bench} value={score} color={benchColors[bench] || '#76b900'} />
        ))}
      </div>

      {/* Footer */}
      <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #1e293b', display: 'flex', gap: 6 }}>
        <MFButton variant="secondary" size="sm">Run Inference</MFButton>
        <MFButton variant="ghost" size="sm">View Lineage</MFButton>
      </div>
    </div>
  );
}

function GenCompareCard({ gen }) {
  const parentAvg = Object.values(gen.parentScores).reduce((a, b) => a + b, 0) / Object.values(gen.parentScores).length;
  const childAvg  = Object.values(gen.childScores).reduce((a, b) => a + b, 0) / Object.values(gen.childScores).length;
  const delta = childAvg - parentAvg;
  const promoted = delta > 0;

  return (
    <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, padding: 18, height: '100%', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Latest Generation</span>
        <Badge type={promoted ? 'promoted' : 'discarded'}>{promoted ? 'Promoted' : 'Discarded'}</Badge>
      </div>

      {/* Parent vs child avg */}
      <div style={{ display: 'flex', gap: 20, marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 3 }}>Parent</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '1.6rem', fontWeight: 500, color: '#94a3b8', lineHeight: 1 }}>{parentAvg.toFixed(3)}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', color: delta > 0 ? '#22c55e' : '#ef4444', fontSize: 18 }}>
          {delta > 0 ? '↑' : '↓'}
        </div>
        <div>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 3 }}>Child</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '1.6rem', fontWeight: 500, color: promoted ? '#76b900' : '#ef4444', lineHeight: 1 }}>{childAvg.toFixed(3)}</div>
        </div>
        <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 3 }}>Delta</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '1.6rem', fontWeight: 600, color: delta > 0 ? '#22c55e' : '#ef4444', lineHeight: 1 }}>
            {delta > 0 ? '+' : ''}{delta.toFixed(3)}
          </div>
        </div>
      </div>

      {/* Benchmark breakdown */}
      <div style={{ marginBottom: 12 }}>
        {Object.keys(gen.parentScores).map(bench => {
          const pd = gen.parentScores[bench];
          const cd = gen.childScores[bench];
          const d = cd - pd;
          return (
            <div key={bench} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5, fontSize: 11 }}>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", color: '#475569', width: 100, flexShrink: 0 }}>{bench}</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", color: '#94a3b8', width: 48 }}>{pd.toFixed(3)}</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", color: d > 0 ? '#22c55e' : d < 0 ? '#ef4444' : '#475569', width: 52, fontWeight: 600 }}>
                {d > 0 ? '+' : ''}{d.toFixed(3)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Weak categories */}
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 10 }}>
        {gen.weakCategories.map(cat => (
          <span key={cat} style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#f59e0b', background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.25)', padding: '2px 7px', borderRadius: 4 }}>
            {cat}
          </span>
        ))}
      </div>

      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#475569' }}>
        {gen.trainingSamples.toLocaleString()} samples · {gen.decisionReason}
      </div>
    </div>
  );
}

Object.assign(window, { ChampionCard, GenCompareCard, ScoreBar });
