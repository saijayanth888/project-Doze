// ModelForge — TopBar Component
// Depends on: Shared.jsx

function TopBar({ gpuUtil, vramUsed, vramTotal, activeRuns, championGen }) {
  return (
    <div style={{
      height: 56, background: '#0c1018', borderBottom: '1px solid #1e293b',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 20px', flexShrink: 0, zIndex: 50,
    }}>
      {/* Left: breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, color: '#475569' }}>ModelForge</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1e293b" strokeWidth="2"><polyline points="9,18 15,12 9,6"/></svg>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, color: '#f1f5f9', fontWeight: 500 }}>Dashboard</span>
      </div>

      {/* Right: system status indicators */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
        {/* GPU */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
            <rect x="4" y="8" width="16" height="12" rx="2"/>
            <path d="M8 8V6"/><path d="M12 8V6"/><path d="M16 8V6"/>
            <path d="M8 20v2"/><path d="M12 20v2"/><path d="M16 20v2"/>
          </svg>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: gpuUtil > 80 ? '#f59e0b' : '#94a3b8' }}>
            GPU {gpuUtil}%
          </span>
        </div>
        {/* VRAM */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 20h20"/><rect x="4" y="4" width="16" height="12" rx="1"/>
            <path d="M8 4v12"/><path d="M16 4v12"/>
          </svg>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#94a3b8' }}>
            {vramUsed}/{vramTotal}GB
          </span>
        </div>
        {/* Active runs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <LiveDot color={activeRuns > 0 ? '#76b900' : undefined} idle={activeRuns === 0} />
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: activeRuns > 0 ? '#76b900' : '#475569' }}>
            {activeRuns > 0 ? `${activeRuns} run${activeRuns > 1 ? 's' : ''} active` : 'idle'}
          </span>
        </div>
        {/* Champion gen */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, borderLeft: '1px solid #1e293b', paddingLeft: 16 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#76b900" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/>
            <path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/>
            <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/>
            <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>
          </svg>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#76b900', fontWeight: 600 }}>
            Gen {championGen}
          </span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { TopBar });
