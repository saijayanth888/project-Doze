// ModelForge — Evolution Status Panel
// Depends on: Shared.jsx

const EVOLUTION_STEPS = ['Evaluate', 'Identify', 'Curate', 'Train', 'Compare', 'Decide', 'Record'];

function EvolutionStatus({ status, currentStep, generation, elapsed, runId, onStart, onStop }) {
  const isRunning = status === 'running';
  const stepIndex = EVOLUTION_STEPS.findIndex(s => s.toLowerCase() === currentStep?.toLowerCase());

  return (
    <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, padding: 20, position: 'relative', overflow: 'hidden' }}>
      {/* Animated gradient border when running */}
      {isRunning && (
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 8, zIndex: 0,
          background: 'conic-gradient(from var(--a, 0deg), #818cf8, #c084fc, #f472b6, #818cf8)',
          animation: 'mf-spin 3s linear infinite',
          padding: 1,
        }}>
          <div style={{ position: 'absolute', inset: 1, background: '#111827', borderRadius: 7 }} />
        </div>
      )}

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {isRunning && <LiveDot />}
            <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Evolution Status</span>
          </div>
          <Badge type={isRunning ? 'running' : 'idle'}>{isRunning ? 'Running' : 'Idle'}</Badge>
        </div>

        {/* Big generation number */}
        <div style={{ display: 'flex', gap: 32, marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 4 }}>Generation</div>
            <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '3rem', fontWeight: 500, color: '#f1f5f9', lineHeight: 1 }}>{generation}</div>
          </div>
          <div>
            <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 4 }}>Elapsed</div>
            <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: '3rem', fontWeight: 500, color: isRunning ? '#76b900' : '#475569', lineHeight: 1 }}>{elapsed}</div>
          </div>
          {runId && (
            <div>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 4 }}>Run ID</div>
              <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 500, color: '#94a3b8', marginTop: 10 }}>{runId}</div>
            </div>
          )}
        </div>

        {/* Steps */}
        <div style={{ display: 'flex', gap: 0, marginBottom: 16, position: 'relative' }}>
          {/* connector line */}
          <div style={{ position: 'absolute', top: 14, left: 14, right: 14, height: 1, background: '#1e293b', zIndex: 0 }} />
          {EVOLUTION_STEPS.map((step, i) => {
            const done = i < stepIndex;
            const active = i === stepIndex;
            return (
              <div key={step} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, position: 'relative', zIndex: 1 }}>
                <div style={{
                  width: 28, height: 28, borderRadius: '50%',
                  background: done ? 'rgba(118,185,0,0.15)' : active ? 'rgba(118,185,0,0.2)' : '#111827',
                  border: `2px solid ${done ? '#76b900' : active ? '#76b900' : '#1e293b'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: active ? '0 0 12px rgba(118,185,0,0.4)' : 'none',
                }}>
                  {done
                    ? <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#76b900" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20,6 9,17 4,12"/></svg>
                    : active ? <LiveDot color="#76b900" /> : null}
                </div>
                <span style={{ fontSize: 10, color: active ? '#f1f5f9' : done ? '#76b900' : '#475569', fontFamily: "'Outfit',sans-serif", fontWeight: active ? 600 : 400, textAlign: 'center' }}>{step}</span>
              </div>
            );
          })}
        </div>

        {/* Controls */}
        <div style={{ display: 'flex', gap: 8 }}>
          {isRunning
            ? <MFButton variant="danger" onClick={onStop} size="sm">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>
                Stop Run
              </MFButton>
            : <MFButton variant="primary" onClick={onStart} size="sm">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polygon points="5,3 19,12 5,21"/></svg>
                Start Evolution
              </MFButton>
          }
          <MFButton variant="ghost" size="sm">View Logs</MFButton>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EvolutionStatus });
