// ModelForge — Activity Feed Component
// Depends on: Shared.jsx

const EVENT_TYPES = {
  promoted:  { color: '#76b900',  label: 'Promoted'  },
  discarded: { color: '#ef4444',  label: 'Discarded' },
  training:  { color: '#818cf8',  label: 'Training'  },
  weakness:  { color: '#f59e0b',  label: 'Weakness'  },
  eval:      { color: '#38bdf8',  label: 'Eval'      },
  started:   { color: '#22c55e',  label: 'Started'   },
};

function ActivityFeed({ events }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1e293b', borderRadius: 8, padding: '16px 0', display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ padding: '0 16px 12px', borderBottom: '1px solid #1e293b' }}>
        <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#475569' }}>Activity</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {events.map((ev, i) => {
          const t = EVENT_TYPES[ev.type] || EVENT_TYPES.eval;
          return (
            <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 16px', alignItems: 'flex-start', borderBottom: i < events.length - 1 ? '1px solid rgba(30,41,59,0.5)' : 'none' }}>
              <div style={{ width: 7, height: 7, borderRadius: '50%', background: t.color, flexShrink: 0, marginTop: 5, boxShadow: `0 0 5px ${t.color}66` }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "'Outfit',sans-serif", fontSize: 12, color: '#94a3b8', lineHeight: 1.4 }}>{ev.text}</div>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#475569', marginTop: 3 }}>{ev.time}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { ActivityFeed });
