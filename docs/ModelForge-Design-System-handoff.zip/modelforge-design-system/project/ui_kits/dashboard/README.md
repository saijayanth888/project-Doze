# ModelForge Dashboard UI Kit

## Overview
Full hi-fi interactive prototype of the ModelForge Evolution Dashboard. Dark luxe-industrial aesthetic. All 5 pages implemented as a single-page React app.

## Pages
| Route/Page | Description |
|---|---|
| Dashboard | KPI cards, evolution status, score trends, champion + latest gen comparison, GPU monitor, activity feed |
| Lineage Tree | D3 interactive family tree of all 47 generations. Click nodes for detail panel. Zoom/pan. |
| Benchmarks | Heatmap table, sortable by any column, all 47 generations × 5 benchmarks |
| Playground | Side-by-side prompt comparison across any two generations |
| Settings | Evolution config sliders, benchmark selection, API keys, system info |

## Components
| File | Exports |
|---|---|
| `Shared.jsx` | `MFLogo`, `LiveDot`, `Badge`, `KPICard`, `SectionHeader`, `MFButton`, `EvolutionStep` |
| `Sidebar.jsx` | `Sidebar` |
| `TopBar.jsx` | `TopBar` |
| `EvolutionStatus.jsx` | `EvolutionStatus` |
| `ActivityFeed.jsx` | `ActivityFeed` |
| `ChampionCard.jsx` | `ChampionCard`, `GenCompareCard`, `ScoreBar` |
| `ScoreTrendsChart.jsx` | `ScoreTrendsChart` |
| `LineageTree.jsx` | `LineageTree` |

## Usage
Open `index.html` directly in browser. All 47 generations of mock data generated on load.

## Dependencies (CDN)
- React 18.3.1
- Recharts 2.12.7
- D3 7.9.0
- JetBrains Mono + Outfit + Instrument Serif (Google Fonts)
