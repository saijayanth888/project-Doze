// ModelForge — Sidebar Component
// Depends on: Shared.jsx

const SIDEBAR_NAV = [
  { id: 'dashboard',  label: 'Dashboard',     icon: 'grid' },
  { id: 'lineage',    label: 'Lineage Tree',   icon: 'branch' },
  { id: 'benchmarks', label: 'Benchmarks',     icon: 'bar' },
  { id: 'playground', label: 'Playground',     icon: 'chat' },
  { id: 'settings',   label: 'Settings',       icon: 'settings' },
];

function NavIcon({ name }) {
  const props = { width: 16, height: 16, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.75, strokeLinecap: "round", strokeLinejoin: "round" };
  if (name === 'grid')     return <svg {...props}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>;
  if (name === 'branch')   return <svg {...props}><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>;
  if (name === 'bar')      return <svg {...props}><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
  if (name === 'chat')     return <svg {...props}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
  if (name === 'settings') return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93A10 10 0 1 0 4.93 19.07"/></svg>;
  if (name === 'chevron')  return <svg {...props}><polyline points="15,18 9,12 15,6"/></svg>;
  return null;
}

function Sidebar({ activePage, onNavigate, collapsed, onToggle, champion }) {
  const sidebarStyle = {
    width: collapsed ? 64 : 240,
    minWidth: collapsed ? 64 : 240,
    background: '#0c1018',
    borderRight: '1px solid #1e293b',
    display: 'flex',
    flexDirection: 'column',
    transition: 'width 250ms cubic-bezier(0.16,1,0.3,1)',
    overflow: 'hidden',
    position: 'relative',
    zIndex: 20,
  };

  return (
    <div style={sidebarStyle}>
      {/* Logo */}
      <div style={{ padding: '16px 14px 12px', borderBottom: '1px solid #1e293b', display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'space-between' }}>
        <MFLogo size="md" collapsed={collapsed} />
        <button onClick={onToggle} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#475569', padding: 4, borderRadius: 4, display: collapsed ? 'none' : 'flex', transition: 'color 150ms' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="15,18 9,12 15,6"/></svg>
        </button>
      </div>

      {/* Champion box */}
      {!collapsed && champion && (
        <div style={{ margin: '10px 12px', padding: '10px 12px', background: '#111827', border: '1px solid rgba(118,185,0,0.2)', borderRadius: 8 }}>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#475569', marginBottom: 4 }}>Champion</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: '#76b900', fontWeight: 600 }}>{champion.name}</div>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#475569', marginTop: 2 }}>
            Gen {champion.generation} · Score {champion.score}
          </div>
        </div>
      )}
      {collapsed && (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#76b900', boxShadow: '0 0 6px rgba(118,185,0,0.5)' }} />
        </div>
      )}

      {/* Nav items */}
      <div style={{ flex: 1, padding: '8px 0' }}>
        {!collapsed && (
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#475569', padding: '8px 16px 4px' }}>Navigation</div>
        )}
        {SIDEBAR_NAV.map(item => {
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              title={collapsed ? item.label : undefined}
              style={{
                display: 'flex', alignItems: 'center', gap: 10,
                width: '100%', padding: collapsed ? '10px 0' : '8px 16px',
                justifyContent: collapsed ? 'center' : 'flex-start',
                background: isActive ? 'rgba(118,185,0,0.06)' : 'transparent',
                border: 'none', borderLeft: isActive ? '2px solid #76b900' : '2px solid transparent',
                cursor: 'pointer', transition: 'all 150ms', outline: 'none',
                color: isActive ? '#76b900' : '#475569',
              }}
            >
              <NavIcon name={item.icon} />
              {!collapsed && (
                <span style={{ fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: isActive ? 600 : 400, color: isActive ? '#76b900' : '#475569', whiteSpace: 'nowrap' }}>
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Start evolution CTA */}
      {!collapsed && (
        <div style={{ padding: '12px', borderTop: '1px solid #1e293b' }}>
          <button style={{
            width: '100%', padding: '10px', background: '#76b900', color: '#000',
            border: 'none', borderRadius: 6, cursor: 'pointer',
            fontFamily: "'Outfit',sans-serif", fontSize: 13, fontWeight: 700,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            boxShadow: '0 0 20px rgba(118,185,0,0.3)', transition: 'all 150ms',
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polygon points="5,3 19,12 5,21"/></svg>
            Start Evolution
          </button>
        </div>
      )}
      {collapsed && (
        <div style={{ padding: '10px 0', borderTop: '1px solid #1e293b', display: 'flex', justifyContent: 'center' }}>
          <button style={{ width: 36, height: 36, background: '#76b900', border: 'none', borderRadius: 6, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 16px rgba(118,185,0,0.3)' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2.5" strokeLinecap="round"><polygon points="5,3 19,12 5,21"/></svg>
          </button>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Sidebar });
