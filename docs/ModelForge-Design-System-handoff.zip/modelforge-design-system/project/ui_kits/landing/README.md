# ModelForge Landing Page UI Kit

## Overview
Full hi-fi interactive prototype of the ModelForge public-facing landing page. Editorial-meets-mission-control aesthetic. Single-page React app.

## Sections
| Section | Description |
|---|---|
| Nav | Fixed top bar with blur backdrop, logo, nav links, CTA |
| Hero | Full-viewport with Instrument Serif headline, gradient text, CTAs, stats, dot-grid bg |
| Live Ticker | Auto-scrolling status ticker: generation, score, last evolution time |
| How It Works | 6-step evolution loop grid with hover states |
| Architecture | Interactive component diagram — hover each service for detail |
| Open Source CTA | GitHub stats, tech stack badges, CTA buttons |
| Footer | Minimal links + "Built on DGX Spark" badge |

## Components
All in `index.html` as inline Babel/JSX:
- `Logo` — SVG mark + DM Sans wordmark
- `Nav` — fixed top nav with backdrop blur
- `LiveTicker` — infinite scroll animation
- `Hero` — full-viewport hero with gradient headline
- `HowItWorks` — 6-step grid
- `Architecture` — interactive component diagram
- `OpenSourceCTA` — community section
- `Footer` — minimal footer

## Usage
Open `index.html` directly in browser. "View Dashboard →" button links to dashboard note.

## Dependencies (CDN)
- React 18.3.1
- IBM Plex Mono + DM Sans + Instrument Serif (Google Fonts)
